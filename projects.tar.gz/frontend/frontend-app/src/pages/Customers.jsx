export default function ProjectsList() {
  return <div className="text-gray-800">Projects list goes here.</div>;
}

