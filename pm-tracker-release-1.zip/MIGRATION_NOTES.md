# PM Tracker - First Release (Backend + Frontend) for MySQL

## What this adds
- Backend (Node 20 + Express) with RBAC (super_admin, pm_admin, pm_user, finance)
- Auth (login/refresh/logout) with Argon2 hashing and refresh-token storage
- Projects endpoints (list/create/update; finance-only patch)
- Payment Terms management (CRUD)
- Configuration management for dropdown lists (customers, segments, service_lines, partners) and statuses (project/invoice/po)
- OpenAPI spec (`backend/openapi.yaml`)
- Docker (MySQL 8 + API), `.env.example`, migration + seed scripts
- Frontend (React + Vite): Projects menu with View Projects, New Project, Payment Terms, and Config page for dropdowns/statuses

## Setup (local)
1. Copy `backend/.env.example` to `backend/.env` and adjust DB credentials if needed.
2. From `backend/`: `npm install && npm run migrate && npm run seed && npm run dev`.
3. From `frontend/`: `npm install && VITE_API_BASE_URL=http://localhost:8080/api npm run dev`.
4. Login on the frontend with `admin@example.com` / `Admin@12345`.

## Docker (full stack)
- From `backend/`: `docker compose up -d --build`. Then run `npm run migrate && npm run seed` once inside the api container or on the host.

## DB Notes
- MySQL schema created under `backend/db/migrations/001_init.sql`.
- `statuses` table holds: `project_status`, `invoice_status`, `po_status`.

## Integrate into your repo
- Replace or merge your existing `backend` and `frontend` folders with the ones provided here.
- Commit and push. If you use GitHub Actions, add lint/test steps as needed.

## Next steps (already planned)
- Advanced filters, CSV export, column chooser in Projects list
- Audit log UI
- Fine-grained permissions per field
- E2E tests
